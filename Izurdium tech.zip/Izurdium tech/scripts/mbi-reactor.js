//this is NOT the complete definition for this block! see content/blocks/surge-reactor.hjson for the stats and other properties.
//this is a copy of the Surge Reactor from "Diamong-Ore" mod. Sorry, z0mbiesrock.

const mbiReactorMeltdownFlak = extend(MissileBulletType, {});

mbiReactorMeltdownFlak.speed = 8;
//this does 800 damage per 5 ticks btw.
mbiReactorMeltdownFlak.damage = 400;
mbiReactorMeltdownFlak.bulletWidth = 16;
mbiReactorMeltdownFlak.bulletHeight = 200;
mbiReactorMeltdownFlak.bulletShrink = 1;
mbiReactorMeltdownFlak.lifetime = 60;
mbiReactorMeltdownFlak.hitEffect = Fx.hitMeltdown;
mbiReactorMeltdownFlak.despawnEffect = Fx.hitMeltdown;
mbiReactorMeltdownFlak.hitSize = 10;
mbiReactorMeltdownFlak.lightining = 10;
mbiReactorMeltdownFlak.lightningLength = 40;
mbiReactorMeltdownFlak.pierce = true;
mbiReactorMeltdownFlak.homingPower= 0;
mbiReactorMeltdownFlak.homingRange= 0;
mbiReactorMeltdownFlak.bulletSprite = "bullet";
mbiReactorMeltdownFlak.frontColor = Color.valueOf("#cd5c5c");
mbiReactorMeltdownFlak.backColor = Color.valueOf("#dc143c");
mbiReactorMeltdownFlak.trailColor = Color.valueOf("#8b0000");

//create a simple shockwave effect
const mbiReactorMeltdownBlast = extend(BasicBulletType, {});

mbiReactorMeltdownBlast.speed = 0.001;
//this does 800 damage per 5 ticks btw.
mbiReactorMeltdownBlast.damage = 400;
mbiReactorMeltdownBlast.drawSize = 500;
mbiReactorMeltdownBlast.lifetime = 1;
mbiReactorMeltdownBlast.hitEffect = Fx.hitMeltdown;
mbiReactorMeltdownBlast.despawnEffect = Fx.nuclearShockwave;
mbiReactorMeltdownBlast.hitSize = 10;
mbiReactorMeltdownBlast.lightining = 10;
mbiReactorMeltdownBlast.lightningLength = 40;
mbiReactorMeltdownBlast.pierce = true;
/* mbiReactorMeltdownBlast.fragVelocityMin = 0.25;
mbiReactorMeltdownBlast.fragVelocityMax = 2.55;
mbiReactorMeltdownBlast.fragBullets = 40;
mbiReactorMeltdownBlast.fragBullet = mbiReactorMeltdownBlast; */
mbiReactorMeltdownBlast.frontColor = Color.valueOf("#cd5c5c");
mbiReactorMeltdownBlast.backColor = Color.valueOf("#dc143c");
mbiReactorMeltdownBlast.trailColor = Color.valueOf("#8b0000");

const mbiReactor = extendContent(NuclearReactor, "mbi-reactor", {
	
    //OVERRIDE
	/* draw: function(tile){
		

        Draw.color(tile.entity.coolColor, tile.entity.hotColor, tile.entity.heat);
        Fill.rect(tile.drawx(), tile.drawy(), size * tilesize, size * tilesize);

        Draw.color(tile.entity.liquids.current().color);
        Draw.alpha(tile.entity.liquids.currentAmount() / liquidCapacity);
        Draw.rect(topRegion, tile.drawx(), tile.drawy());
		
		if(tile.entity.heat > tile.entity.flashThreshold){
            flash = 1 + ((tile.entity.heat - tile.entity.flashThreshold) / (1 - tile.entity.flashThreshold)) * 5.4;
            tile.entity.flash += flash * Time.delta();
            Draw.color(Color.red, Color.yellow, Mathf.absin(tile.entity.flash, 9, 1));
            Draw.alpha(0.6);
            Draw.rect(lightsRegion, tile.drawx(), tile.drawy());
        }
		Draw.alpha(tile.tile.entity.items.total() / tile.tile.entity.itemCapacity);
		Draw.rect(Core.atlas.find(this.name + "-top"), tile.drawx(), tile.drawy());

        Draw.reset();
	}, */
	
    //OVERRIDE
	onDestroyed: function(tile){
		Blocks.thoriumReactor.onDestroyed(tile);
        for(var i = 0; i < 45; i++){
            Calls.createBullet(mbiReactorMeltdownFlak, Team.derelict, tile.worldx(), tile.worldy(), Mathf.random(360), Mathf.random(0.15, 1.0), Mathf.random(0.2, 1.0));
		}
		surgeReactorMeltdownBlast.lightningLength = 65;
        Calls.createBullet(mbiReactorMeltdownBlast, Team.derelict, tile.worldx(), tile.worldy(), Mathf.random(360), Mathf.random(0.5, 1.0), Mathf.random(0.2, 1.0));
		mbiReactorMeltdownBlast.lightningLength = 75;
        Calls.createBullet(mbiReactorMeltdownBlast, Team.derelict, tile.worldx(), tile.worldy(), Mathf.random(360), Mathf.random(0.5, 1.0), Mathf.random(0.2, 1.0));
		mbiReactorMeltdownBlast.lightningLength = 85;
        Calls.createBullet(mbiReactorMeltdownBlast, Team.derelict, tile.worldx(), tile.worldy(), Mathf.random(360), Mathf.random(0.5, 1.0), Mathf.random(0.2, 1.0));
		mbiReactorMeltdownBlast.lightningLength = 95;
        Calls.createBullet(mbiReactorMeltdownBlast, Team.derelict, tile.worldx(), tile.worldy(), Mathf.random(360), Mathf.random(0.5, 1.0), Mathf.random(0.2, 1.0));
		mbiReactorMeltdownBlast.lightningLength = 105;
        Calls.createBullet(mbiReactorMeltdownBlast, Team.derelict, tile.worldx(), tile.worldy(), Mathf.random(360), Mathf.random(0.5, 1.0), Mathf.random(0.2, 1.0));
		mbiReactorMeltdownBlast.lightningLength = 115;
	},
})